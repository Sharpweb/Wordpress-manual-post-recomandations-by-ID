<?php

/**
 * Fired during plugin activation
 *
 * @link       http://sharpweb.ro
 * @since      1.0.0
 *
 * @package    Wp_Mrp
 * @subpackage Wp_Mrp/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wp_Mrp
 * @subpackage Wp_Mrp/includes
 * @author     Valentin Ionel <valentinionel@gmail.com>
 */
class Wp_Mrp_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
