<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://sharpweb.ro
 * @since      1.0.0
 *
 * @package    Wp_Mrp
 * @subpackage Wp_Mrp/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wp_Mrp
 * @subpackage Wp_Mrp/includes
 * @author     Valentin Ionel <valentinionel@gmail.com>
 */
class Wp_Mrp_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
